﻿#pragma once
#include "cCubeNode.h"

class cHead : public cCubeNode
{
public:
	virtual void setup() override;

};
