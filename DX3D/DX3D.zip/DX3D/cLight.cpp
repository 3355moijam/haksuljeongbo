﻿#include "stdafx.h"
#include "cLight.h"

cLight::cLight(): light()
{
}

cLight::~cLight()
{
}

void cLight::setup()
{
}

void cLight::update()
{
}

void cLight::render()
{
}
