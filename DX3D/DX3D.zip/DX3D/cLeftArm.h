﻿#pragma once
#include "cCubeNode.h"

class cLeftArm : public cCubeNode
{
public:
	virtual void setup() override;
};
